package com.classmgt;

public class Student {
	int sid;
	String Sname;
	
	Batch b = new Batch();

}
