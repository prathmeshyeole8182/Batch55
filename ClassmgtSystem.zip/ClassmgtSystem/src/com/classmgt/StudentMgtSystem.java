package com.classmgt;

public class StudentMgtSystem {
	public static void main(String[] args) {
		System.out.println("---Student Information---");
		
		Student s = new Student();
		s.sid = 101;
		s.Sname = "Prathmesh";
		s.b.bid = 102;
		s.b.bname = "Morning";
		s.b.f.fid = 103;
		s.b.f.fname = "Raj Sir";
		s.b.f.c.cid = 104;
		s.b.f.c.cname = "Java";
		
		System.out.println(" "+s.sid + " "+ s.Sname+ "\n "+ s.b.bid+" "+ s.b.bname+ "\n "+ s.b.f.fid+ " "+ s.b.f.fname+ "\n "+s.b.f.c.cid+ " "+s.b.f.c.cname);
		
	}

}
