package com.classmgt;

public class Batch {
	int bid;
	String bname;
	
	Faculty f = new Faculty();

}
