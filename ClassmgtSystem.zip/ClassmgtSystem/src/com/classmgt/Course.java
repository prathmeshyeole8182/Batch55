package com.classmgt;

public class Course {
	int cid;
	String cname;
	
	

}
