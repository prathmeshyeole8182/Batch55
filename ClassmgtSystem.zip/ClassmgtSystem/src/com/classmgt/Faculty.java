package com.classmgt;

public class Faculty {
	 
	int fid;
	String fname;
	
	Course c = new Course();

}
