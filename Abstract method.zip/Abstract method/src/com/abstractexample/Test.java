package com.abstractexample;

public  abstract class Test {
	int i;
	String str;
	
	Test(){
		 i = 100;
	  str= "ABC";
	  
	  System.out.println(i + " "+ str);
		
	}
	
	public void m1() {
		System.out.println("m1 method of Test");
	}
	
	public abstract void m2();
	public abstract void m3();
	public abstract void m4();
	

}
