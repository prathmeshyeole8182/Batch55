package com.abstractexample;

public class Demo extends Test {
	
	public static void main(String[] args) {
		Demo d = new Demo();
		d.m1();
		d.m2();
		d.m3();
		d.m4();
		
		Test t = new Demo();
		t.m1();
		t.m2();
		t.m3();
		t.m4();
		
	}

	@Override
	public void m2() {
		System.out.println("m2 methode of Test");
	}

	@Override
	public void m3() {
		System.out.println("m3 method of Test");
	}

	@Override
	public void m4() {
		System.out.println("m4 method of Test");
	}

}
