package com.interfaceexp;

public class ReadFile implements ProcessFile {

	@Override
	public void m1() {
		System.out.println("m1 ReadFile Operation");
	}

	@Override
	public void m2() {
		System.out.println("m2 ReadFile Operation");
	}

}
