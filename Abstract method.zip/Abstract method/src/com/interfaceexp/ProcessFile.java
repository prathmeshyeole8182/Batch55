package com.interfaceexp;

public interface ProcessFile {
	
	public abstract void m1();
	
	public abstract void m2();

}
