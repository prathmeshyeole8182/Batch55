package com.interfaceexp;

public class DelectFile implements ProcessFile{

	@Override
	public void m1() {
		System.out.println("m1 DelectFile Operation");
		
	}

	@Override
	public void m2() {
		System.out.println("m2 Delectfile Operation");
	}

}
