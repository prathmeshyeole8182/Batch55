package com.interfaceexp;

public class MainClass {
	
	public static void main(String[] args) {
		ProcessFile r = new ReadFile();
		r.m1();
		r.m2();
		
		ProcessFile w = new WriteFile();
		w.m1();
		w.m2();
		
		ProcessFile d = new DelectFile();
		d.m1();
	    d.m2();
	}

}
