package com.exponent.bankapp.service;

public interface RBI {
	
	public void createAccount();
	
	public void showAccountDetails();
	
	public void showAccountBalance();
	
	public void depositeMoney();
	
	public void withdrawMoney();
	
	public void updateAccountDetails();
	
	public void displaysingleAccount();

}
