package com.exponent.bankapp.serviceimpl;

import java.util.Scanner;


import com.exponent.bankapp.model.Account;
import com.exponent.bankapp.service.RBI;
import com.exponent.bankapp.validation.Validation;

public class SBI implements RBI {
	
	/* Account ac = new Account(); */
	Account a[] = new Account[5];
	Scanner sc = new Scanner(System.in);

	@Override
	public void createAccount(){
		
		
		System.out.println("How many accounts you want to add:-");
		int n =sc.nextInt();
		
		for(int i = 0; i < n; i++) {
			Account ac = new Account();
		System.out.println("Enter your account number");
	  int accNo = sc.nextInt();
	    ac.setAccountno(accNo);
		//ac.setAccountno(Validation.validateAccountNumber());
		//System.out.println(Validation.validateAccountHolderName());
		ac.setAccountname(Validation.validateAccountHolderName());
		//System.out.println("Enter adhar card number");
		ac.setAdharcard(Validation.validateAdharcardno());
		//System.out.println("Enter pancard number");
		ac.setPancard(Validation.validatePancardno());
		//System.out.println("Enter mail id");
		ac.setMail(Validation.validateMailid());
		//System.out.println("Enter your contact no");
		ac.setContact(Validation.validatecontactno());
		//System.out.println("Enter your account opening balance");
		ac.setAccountbalance(Validation.validateaccountbalance());
		a[i] = ac;
		System.out.println("Account Created Successfully");
		}

	}

	@Override
	public void showAccountDetails() {
		/*
		 * Scanner sc = new Scanner(System.in);
		 * System.out.println("Enter your account number"); int accNo = sc.nextInt(); if
		 * (ac.getAccountno() == accNo) { System.out.println(ac); } else {
		 * System.out.println("Account does't exit"); }
		 */
		System.out.println("---------Display all Accounts");
		for(Account acn : a) {
			if(acn != null) {
				System.out.println(acn);
			}
		}
	}

	@Override
	public void showAccountBalance() {
		/*
		 * Scanner sc = new Scanner(System.in);
		 * System.out.println("Enter your Account"); int accNo = sc.nextInt(); if
		 * (ac.getAccountno() == accNo) { System.out.println("Current account balance "
		 * + ac.getAccountbalance()); } else {
		 * System.out.println("Account does't exit "); }
		 */
		System.out.println("Enter Your Account number");
		int accNo = sc.nextInt();
		for(Account acn : a ) {
			if((acn != null) && (acn.getAccountno() == accNo)) {
				System.out.println(acn.getAccountbalance());
			}
		}

	}

	@Override
	public void depositeMoney() {
		/*
		 * Scanner sc = new Scanner(System.in);
		 * System.out.println("enter your account"); int accNo = sc.nextInt(); if
		 * (ac.getAccountno() == accNo) {
		 * System.out.println("Enter amount you want to deposite"); double add =
		 * sc.nextDouble(); double updateAccountDetails = add + ac.getAccountbalance();
		 * ac.setAccountbalance(updateAccountDetails);
		 * System.out.println("Total Balance : " + ac.getAccountbalance()); } else {
		 * System.out.println("please deposite amount above 1000"); }
		 */

		System.out.println("Enter Your Account Number:-");
		int accNo = sc.nextInt();
		for(Account acn : a) {
			if((acn != null) && (acn.getAccountno() == accNo)){
				System.out.println("Enter Amount to be Deposited");
				double amt = sc.nextDouble();
				double totalamt = amt + acn.getAccountbalance();
				acn.setAccountbalance(totalamt);
				System.out.println("Deposit Succesful!\n Your Current Balance Is : "+ acn.getAccountbalance());
			}
		}
	}

	@Override
	public void withdrawMoney() {
		/*
		 * Scanner sc = new Scanner(System.in);
		 * System.out.println("enter your account"); int accNo = sc.nextInt(); if
		 * (ac.getAccountno() == accNo) {
		 * System.out.println("Enter amount you want to Withdraw"); double add =
		 * sc.nextDouble(); double updateAccountDetails = ac.getAccountbalance() - add;
		 * ac.setAccountbalance(updateAccountDetails);
		 * System.out.println("Remaining Amount: " + ac.getAccountbalance()); } else {
		 * System.out.println("please withdraw  minimum 500"); }
		 */
		System.out.println("Enter Your Account Number:-");
		int accNo = sc.nextInt();
		for(Account acn : a) {
			if(acn != null && acn.getAccountno() == accNo ) {
				System.out.println("Enter Amount to be Withdrawn");
				double amt = sc.nextDouble();
				acn.setAccountbalance(amt);
				System.out.println("Deposit Successful!\n Your Current Balance is: "+ acn.getAccountbalance());
			}else {
				System.out.println("Insufficient Balance!\n Your Current Balance is: "+ acn.getAccountbalance());
			}
		}
	}

	@Override
	public void updateAccountDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your account number");
		int accNo = sc.nextInt();
		boolean d = true;
		/*
		 * if (ac.getAccountno() == accNo) {
		 * 
		 * while (d) { System.out.println("------------------------");
		 * System.out.println("1: Update Name         |");
		 * System.out.println("2: Update Number       |");
		 * System.out.println("3: Exit                |");
		 * System.out.println("------------------------");
		 * 
		 * System.out.println("Enter Your choice between 1 to 3");
		 * 
		 * int sh = sc.nextInt();
		 * 
		 * switch (sh) { case 1: System.out.println("Enter your new name"); String
		 * newName = sc.next(); this.ac.setAccountname(newName); break;
		 * 
		 * case 2: System.out.println("Enter your number"); long newNumber =
		 * sc.nextLong(); this.ac.setContact(newNumber); break;
		 * 
		 * case 3: d = false; break;
		 * 
		 * default: System.out.println("Enter invalid choice pls enter correct choice");
		 * break; } } } else { System.out.println("Enter valid account number"); }
		 * System.out.println("Account update Successfully");
		 */
		for(Account acn : a) {
			if((acn != null) && (acn.getAccountno() == accNo)) {
				
				while(d) {
					System.out.println("------------------------");
					System.out.println("1: Update Name         |");
					System.out.println("2: Update Number       |");
					System.out.println("3: Exit                |");
					System.out.println("------------------------");
					int ch = sc.nextInt();
					switch(ch) {
					case 1:
						acn.setAccountname(Validation.validateAccountHolderName());
						System.out.println("Name Updated Successfully");
						break;
					case 2:
						acn.setContact(Validation.validatecontactno());
						break;
					case 3:
						d = false;
						break;
						default:
							System.out.println("Invalid Option! Select Appropriate Option:");
					}
				}
			}
		}
	}

	@Override
	public void displaysingleAccount() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Account Number:-");
		long an = sc.nextLong();
		for(Account acn : a) {
			if(acn != null && acn.getAccountno() == an) {
				System.out.println(acn);
			}
		}
		
	}

}
