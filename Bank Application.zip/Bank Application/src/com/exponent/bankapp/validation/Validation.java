package com.exponent.bankapp.validation;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Validation {

	public static String validateAccountHolderName() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Name :- ");
		String name = sc.next();
		char[] ch = name.toCharArray();
		boolean flag = true;
		for (int i = 0; i < ch.length; i++) {
			if (!(name.charAt(i) >= 'a' && name.charAt(i) <= 'z')
					&& !(name.charAt(i) >= 'A' && name.charAt(i) <= 'Z')) {

				flag = false;
			}
		}

		if (!flag) {
			System.out.println("Invalid I/p");
			return validateAccountHolderName();
		}

		return name;

	}

	/*
	 * public static int validateAccountNumber() {
	 * 
	 * Scanner sc = new Scanner(System.in);
	 * System.out.println("Enter your account number"); String name = sc.next(); int
	 * accNo = Int.value
	 * 
	 * if (Pattern.matches("[0-9]+", name)) {
	 * System.out.println("valid account number");
	 * 
	 * } else { System.out.println("Invalid account number"); return
	 * validateAccountNumber(); } return accNo; }
	 */

	public static String validateAdharcardno() {
		//String adhar = "373201383100";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Adhar card NO:-");
		String adhar = sc.next();
		if (Pattern.matches("[0-9]{12}", adhar)) {
			System.out.println("Valid");
		} else {
			System.out.println("Invalid");
			return validateAdharcardno();
		}
		return adhar;
	}

	public static String validatePancardno() {
		//String pancard = "AZDPY4818J";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Pan card NO:-");
		String pancard = sc.next();
		if (Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}", pancard)) {
			System.out.println("Valid");
		} else {
			System.out.println("Invalid");
			return validatePancardno();
		}
		return pancard;
	}

	public static String validateMailid() {
		/*
		 * String mailid = "prathmesh4gmailcom"; Scanner sc = new Scanner(System.in);
		 * System.out.println("Enter Your Mailid:-"); String name = sc.next();
		 * if(Pattern.matches("[a-z][0-9][A-Z]", mailid)) { System.out.println("Valid");
		 * }else { System.out.println("Invalid"); return validateMailid(); } return
		 * mailid;
		 */
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Mailid :- ");
		String name = sc.next();
		char[] ch = name.toCharArray();
		boolean flag = true;
		for (int i = 0; i < ch.length; i++) {
			if (!(name.charAt(i) >= 'a' && name.charAt(i) <= 'z')
					&& !(name.charAt(i) >= 'A' && name.charAt(i) <= 'Z')) {

				flag = false;
			}
		}

		if (!flag) {
			System.out.println("Invalid I/p");
			return validateMailid();
		}

		return name;

	}

	public static long validatecontactno() {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Contact NO:-");
		String number = getvalidate
		long con = Long.valueOf(number);
		if (Pattern.matches("[0-9]{10}", number)) {
			System.out.println("Valid");
		} else {
			System.out.println("Invalid");
			return validatecontactno();
		}
		return con;

	}

	public static double validateaccountbalance() {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your account opening balance:-");	
		String name = sc.next();
		double b = Double.valueOf(name);
		if (Pattern.matches("[0-9]+", name)) {
			System.out.println("Valid");
		} else {
			System.out.println("Invalid");
			return validateaccountbalance();
		}
		return b;

	}

}
