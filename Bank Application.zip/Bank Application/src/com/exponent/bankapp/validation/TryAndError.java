package com.exponent.bankapp.validation;

import java.util.regex.Pattern;

public class TryAndError {
	
	public static void main(String[] args) {
		
		String name = "Prathmesh";
		if(Pattern.matches("[a-zA-Z]", name)) {
			System.out.println("Valid Username");
		}else {
			System.out.println("Invalid Username");
		}
	}

}
