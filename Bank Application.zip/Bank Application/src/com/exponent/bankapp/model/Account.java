package com.exponent.bankapp.model;

public class Account {
	
	private int accountno;
	private String accountname;
	private String adharcard;
	private String pancard;
	private long contact;
	private String mail;
	private double accountbalance;
	
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public String getAccountname() {
		return accountname;
	}
	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}
	public String getAdharcard() {
		return adharcard;
	}
	public void setAdharcard(String adharcard) {
		this.adharcard = adharcard;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public double getAccountbalance() {
		return accountbalance;
	}
	public void setAccountbalance(double accountbalance) {
		this.accountbalance = accountbalance;
	}
	@Override
	public String toString() {
		return "Account [accountno=" + accountno + ", accountname=" + accountname + ", adharcard=" + adharcard
				+ ", pancard=" + pancard + ", contact=" + contact + ", mail=" + mail + ", accountbalance="
				+ accountbalance + "]";
	}
	

		
	

}
