package com.protectclass;
import com.AM.PrivateTest;
 class ProtectExample extends PrivateTest {
	
	public static void main(String[] args) {
		ProtectExample pe = new ProtectExample();
		pe.m5();
		pe.m6();
	}

}
