package com.AM;

public class PrivateTest {
	int i = 200;
	private void m1() {
		System.out.println("Private Method");
	}
	 void m2() {
		System.out.println("Default Method");
		
	}
	 public static void main(String[] args) {
		PrivateTest p = new PrivateTest();
		p.m1();
		p.m2();
		p.m7();
		p.m5();
		p.m6();
	 }
		protected void m5() {
			System.out.println("\nProtected Methode");
		}
		protected void m6() {
			System.out.println("\nInheritance Use");
		}
		private void m7()
		{
			System.out.println("\nPrivate use in access modifier");
		}	
		

}
