package com.AM;

public class PrivateTest1 {
	public static void main(String[] args) {
		PrivateTest pt = new PrivateTest();
		pt.m5();
		//pt.m1();
		pt.m2();
	}

}
