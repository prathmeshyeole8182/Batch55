package com.AM;

import com.accessmodifier.PublicClass;

public class Democlass {

	public static void main(String[] args) {

		PublicClass p = new PublicClass();
		p.m1();
		
		
	}

}
