package com.accessmodifier;

public class Mainclass {
	
	public static void main(String[] args) {
		DefaultTest dt = new DefaultTest();
		dt.m1();
		System.out.println(dt.eid);
		
		Private p = new Private();
		p.m1();
		
	}

	
}
