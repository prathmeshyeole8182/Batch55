package com.accessmodifier;

public class Private {
	
	private int id = 100;
	private String name = "Yash";
	
	public void m1() {
		System.out.println("m1 methode");
		System.out.println("---400 lines code---");
		m2();
		
	}
	
	private void m2() {
		System.out.println("---200 lines code---");
		
	}
	
	public static void main(String[] args) {
		Private p = new Private();
		System.out.println(p.id);
		System.out.println(p.name);
		p.m1();
	}

}
