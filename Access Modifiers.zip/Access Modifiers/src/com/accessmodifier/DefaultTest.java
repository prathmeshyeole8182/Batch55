package com.accessmodifier;

public class DefaultTest {

	int eid = 5000;
	
	 DefaultTest() {
		System.out.println("Default Constructor");
	}
	 
	 void m1() {
		 System.out.println("Default method");
	 }
	 
	 public static void main(String[] args) {
		DefaultTest d = new DefaultTest();
		System.out.println(d.eid);
		d.m1();
	}
}
