package com.accessmodifier;

public class PublicClass {
	int eid = 100;
	String name = "Prathmesh";
	
	public void m1() {
		System.out.println("Public class methode");
	}
	
	public PublicClass(){
		System.out.println("Constructor");
	}
	
	public static void main(String[] args) {
		PublicClass pc = new PublicClass();
		System.out.println(pc.eid);
		System.out.println(pc.name);
		pc.m1();
		
		
	}

}
