
public class data {
	int x = 9000;
	String y = "india";
	String yp = "machines";

	public void MachinesData() {
		System.out.println("---machine information---");
		int code = 9090;
		String name = "lathe machines";
		String add = "mumbai";
		System.out.println(code);
		System.out.println(name);
		System.out.println(add);

	}

	public void machineQuantity() {
		System.out.println("machine quantity");
		int Q = 12000;
		String location = "delhi";
		int pincode = 411033;
		System.out.println(Q);
		System.out.println(location);
		System.out.println(pincode);

	}

	public void m1() {
		System.out.println("m1 data");
		data all = new data();
		System.out.println(all.x + " " + all.y + " " + all.yp);

	}

	public static void main(String[] args) {
		System.out.println("All machines data");
		data a = new data();
		a.MachinesData();
		a.machineQuantity();
		a.m1();

	}
}
