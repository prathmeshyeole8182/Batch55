public class object {
	int numbers = 500;
	String name = "prathmesh";
	data a = new data();
	
	public void m1()
	{
		System.out.println("---machine objects---");
		int id = 8888;
		String add = "pune";
		System.out.println(id);
		System.out.println(add);
		
				
	}
	public void m2()
	{
	 System.out.println("---all types of objects");
	 int code = 9090;
	 String lang = "english";
	 System.out.println(code);
	 System.out.println(lang);
	 
	
	}
	
	public static void main(String[] args) {
System.out.println("hello java");
System.out.println("2nd statement of eciplse");
object all = new object();
System.out.println(all.numbers);
System.out.println("name");
all.m1();
all.m2();





	}
}
