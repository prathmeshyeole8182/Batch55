package com.datatypes;

public class Mobile {

	String name = "Iphone";
	byte ram = 12;
	short storage = 512;
	int price = 120000;
	long id = 8806413740l;
	float battery = 100.00f;
	double emicode = 98.679544;
	boolean warrenty = true;
	char grade = 'A';

	String ename;
	byte eram;
	short estorage;
	int eprice;
	long eid;
	float ebattery;
	double eemicode;
	boolean ewarrenty;
	char egrade;

	public static void main(String[] args) {
		Mobile m = new Mobile();
		System.out.println(m.name);
		System.out.println(m.ram);
		System.out.println(m.storage);
		System.out.println(m.price);
		System.out.println(m.id);
		System.out.println(m.battery);
		System.out.println(m.emicode);
		System.out.println(m.warrenty);
		System.out.println(m.grade);

		
		System.out.println(m.ename);
		System.out.println(m.eram);
		System.out.println(m.estorage);
		System.out.println(m.eprice);
		System.out.println(m.eid);
		System.out.println(m.ebattery);
		System.out.println(m.eemicode);
		System.out.println(m.ewarrenty);
		System.out.println(m.egrade);
	}

}
