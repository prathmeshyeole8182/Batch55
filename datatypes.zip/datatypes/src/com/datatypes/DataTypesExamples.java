package com.datatypes;

public class DataTypesExamples {


	public void m1() {
		System.out.println("all datatypes examples");
		byte b1 = 100;
		short s1 = 1000;
		int i1 = 32000;
		long l1 = 80000000899l;
		float f1 = 43.78f;
		double d1 = 123.45;
		boolean flag1 = true;
		char c1 = 'R';
System.out.println(b1);
System.out.println(s1);
System.out.println(i1);
System.out.println(l1);
System.out.println(f1);
System.out.println(d1);
System.out.println(flag1);
System.out.println(c1);
	}

	public static void main(String[] args) {
		DataTypesExamples d = new DataTypesExamples();
		d.m1();

	}

}
