package com.datatypes;

public class Employee {

	String name = "RAJ";
	byte eid = 15;
	short adhar = 19065;
	int account = 22908763;
	long mobile = 8806413740l;
	float percen = 88.90f;
	double balance = 88.97456;
	boolean developer = true;
	char grade = 'B';

	public static void main(String[] args) {
		System.out.println("---Employee Details---");
		Employee e = new Employee();
		System.out.println(e.name);
		System.out.println(e.eid);
		System.out.println(e.adhar);
		System.out.println(e.account);
		System.out.println(e.mobile);
		System.out.println(e.percen);
		System.out.println(e.balance);
		System.out.println(e.developer);
		System.out.println(e.grade);

		System.out.println("\n" +" "+ e.name + " " + e.eid + " " + e.adhar + "\n " + e.account + " " + e.mobile + " "
				+ e.percen + "\n " + e.balance + " " + e.developer + " " + e.grade);
	}

}
